# the median amount of shares is the boundary of our independent variable
print '\nBinary Threshold:'
binary_threshold = np.median(raw_data[' shares']) 

# Binarize the labels
binarizer = Binarizer(threshold=binary_threshold)
y_binary = binarizer.transform(news_labels).transpose().ravel() 

# Preprocess X to standard normal
scalerX = preprocessing.StandardScaler().fit(news_data)
X = scalerX.transform(news_data) 