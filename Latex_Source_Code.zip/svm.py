# cv = amount of cross validation folds
def cv_mean_std_SVM(C, cv):
    lin = svm.SVC(C=C, kernel='linear', max_iter=10000)
    poly_2 = svm.SVC(C=C, kernel='poly', degree=2, max_iter=10000)
    poly_3 = svm.SVC(C=C, kernel='poly', degree=3, max_iter=10000)
    rbf = svm.SVC(C=C, kernel='rbf', max_iter=10000)
    cv_lin = cross_val_score(lin, X, y_binary, cv=cv)#, dual=False)
    print 'finished computing linear cv'
    cv_poly_2 = cross_val_score(poly_2, X, y_binary, cv=cv)#, dual=False)
    print 'finished computing polydeg2 cv'
    cv_poly_3 = cross_val_score(poly_3, X, y_binary, cv=cv)#, dual=False)
    print 'finished computing polydeg3 cv'
    cv_rbf = cross_val_score(rbf, X, y_binary, cv=cv)#, dual=False)
    print 'finished computing rbf cv'
    return np.mean(cv_lin), np.std(cv_lin), np.mean(cv_poly_2), np.std(cv_poly_2), np.mean(cv_poly_3), np.std(cv_poly_3), np.mean(cv_rbf), np.std(cv_rbf)
