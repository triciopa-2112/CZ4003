# Import csv data
raw_data = pd.read_csv('OnlineNewsPopularity_wLabels_deleteNoise.csv').iloc[:, 1:]      # read in csv, omit the first column of url
print np.median(raw_data[' shares'])
# Remove the binarized column of shares
raw_data = raw_data.iloc[:, :-1] 
# Take up to the second last column
news_data = raw_data.iloc[:, :-1]  
# Take shares column for labels
news_labels = raw_data.iloc[:, -1] 